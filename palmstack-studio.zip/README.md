# Portfolio Research Notes

## Top 3 references selected

1. Julian Ozen - clean editorial structure, readable project stories, confident spacing.
   Source: https://www.sitebuilderreport.com/inspiration/software-engineer-portfolios

2. Tamal Sen - strong personal developer feel, clear featured project hierarchy, skill-forward layout.
   Source: https://www.upwork.com/resources/web-developer-portfolio-examples

3. Dave Donnelly - production-quality proof, performance/accessibility framing, specific engineering metrics.
   Source: https://www.davedonnelly.dev/projects/portfolio-2025

## Best practices applied

- Lead with a precise positioning statement instead of a generic greeting.
- Show proof early: years of experience, full-stack breadth, and product ownership.
- Use three detailed project stories instead of a long list of shallow demos.
- Split the stack into backend, data, cloud, and mobile so recruiters can scan quickly.
- Include process, not only tools, to show seniority and end-to-end thinking.
- Keep contact actions visible and simple.
- Use a hybrid freelance identity: your real name for trust, with a lightweight studio label for commercial flexibility.
- Add AI agentic systems as a production capability, not a vague AI badge.

## AI systems stack selected

- Agent orchestration: LangGraph for controllable multi-step agents and OpenAI Agents SDK for handoffs, tools, guardrails, and tracing.
- Python agent framework: Pydantic AI for typed Python agents that fit naturally beside FastAPI.
- Durable workflows: Temporal for long-running agent jobs, retries, approvals, and crash recovery.
- Default AI database: PostgreSQL with pgvector for product data, audit logs, and vector search in one operational database.
- Dedicated retrieval engine: Qdrant when hybrid search, metadata filtering, and vector scale need a specialized service.

Sources:

- https://www.langchain.com/langgraph
- https://openai.github.io/openai-agents-python/tracing/
- https://openai.github.io/openai-agents-python/guardrails/
- https://pydantic.dev/docs/ai/overview/
- https://temporal.io/home
- https://www.enterprisedb.com/docs/edb-postgres-ai/ai-factory/vector-engine/
- https://qdrant.tech/

## Customize before publishing

- Replace `hello@palmstack.studio`, WhatsApp, GitHub, and LinkedIn links in `index.html` with your real contact links.
- Replace the project titles and descriptions with your real shipped products.
- Add live links, repositories, metrics, and screenshots when available.
- The site includes an English/Arabic toggle. Update both language blocks in `script.js` whenever you change customer-facing copy in `index.html`.

## UAE-demand project examples added

The portfolio now includes one realistic project example for each service category, based on recurring UAE market demand:

- MVPs and business platforms: booking, payments, staff scheduling, VAT-aware invoices, and operations dashboards.
- Backend and cloud systems: WhatsApp and ad lead capture, CRM records, owner assignment, follow-ups, and reporting.
- Mobile apps: customer and field-service apps with bookings, status updates, push notifications, payments, and bilingual readiness.
- AI workflow automation: invoice, PO, contract, and form processing with approvals, ERP/CRM updates, and audit logs.

Additional research signals:

- UAE SMEs commonly seek workflow automation around approvals, reporting, document processing, ERP/CRM/email/file integrations, and measurable ROI.
- WhatsApp is repeatedly positioned as a primary UAE customer engagement and lead-capture channel.
- Custom CRM/ERP, cloud backends, API integrations, mobile apps, and AI-enabled operations systems appear repeatedly in UAE software development demand.

## UAE agency benchmark patterns applied

After reviewing UAE-facing technology and digital transformation agencies, the site now includes sections commonly used to build buyer trust:

- Case-study style project cards with challenge, solution, and expected impact.
- Proof metrics near the top of the page.
- Industry fit for UAE buyers.
- Testimonials-style trust copy. Replace these representative quotes with real client testimonials when available.
- A clear process and FAQ to reduce first-contact friction.
- A dedicated contact page with a short qualification form. It balances conversion and lead quality by asking for project type, stage, timeline, budget range, and goal.

## Image strategy

The site uses real tech-oriented Unsplash CDN images with lightweight parameters:

- `fm=webp` for WebP delivery.
- `q=58` for compressed image quality.
- `w=900-1400` depending on display importance.
- `loading="lazy"` and `decoding="async"` for non-hero images.
- Local fallback PNGs in `assets/` if a remote image fails to load.

Current image themes:

- Developer workspace for the hero.
- Analytics dashboard for business platforms.
- Server/cloud infrastructure for backend systems.
- Mobile app screens for mobile delivery.
- AI/data visualization for agentic automation.

Sources:

- https://tekmalia.com/ai-automation-for-smes.aspx
- https://zena.fictoralabs.ae/whatsapp-automation-uae/
- https://botsense.io/whatsapp-automation-uae/
- https://www.apptunix.com/erp-software-development-dubai-uae/
- https://jachoos.solutions/top-10-custom-software-solutions-for-uae-businesses-in-2026/
- https://everestdg.com/mobile-app-development-in-dubai-a-2026-guide-for-uae-businesses/
- https://aijourn.com/why-ai-based-custom-software-development-in-dubai-is-surging-in-2026/
- https://pro71.ae/en/case-studies/
- https://www.prototype.ae/en-us
- https://neologix.ae/services/digital-transformation/
- https://www.igentx.com/case-studies
- https://competenza.ae/blog/top-10-best-software-development-companies-in-uae/
