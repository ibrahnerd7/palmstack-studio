const year = document.querySelector("#year");
const languageToggle = document.querySelector(".language-toggle:not([data-contact-language-toggle])");
const currentLangLabel = document.querySelector("[data-lang-current]");
const nextLangLabel = document.querySelector("[data-lang-next]");
const metaDescription = document.querySelector('meta[name="description"]');
const fallbackImages = document.querySelectorAll("img[data-fallback]");
const contactForm = document.querySelector("[data-contact-form]");
const contactLanguageToggle = document.querySelector("[data-contact-language-toggle]");

if (year) {
  year.textContent = new Date().getFullYear();
}

fallbackImages.forEach((image) => {
  image.addEventListener(
    "error",
    () => {
      const fallback = image.getAttribute("data-fallback");

      if (fallback && image.src !== fallback) {
        image.src = fallback;
      }
    },
    { once: true },
  );
});

const translations = {
  en: {
    metaTitle: "PalmStack Studio | UAE Full-Stack & AI Systems Developer",
    metaDescription:
      "UAE freelance portfolio for a full-stack and AI systems developer building business platforms, mobile apps, cloud backends, and agentic automation.",
    "nav.services": "Services",
    "nav.work": "Work",
    "nav.ai": "AI Systems",
    "nav.proof": "Proof",
    "nav.engagements": "Engagements",
    "nav.contact": "Contact",
    "hero.eyebrow": "PalmStack Studio - independent UAE software partner",
    "hero.title": "Launch the app, automate the workflow, and keep the system reliable.",
    "hero.lede":
      "I help UAE founders and SMEs build web platforms, mobile apps, cloud backends, and production AI agents with one senior full-stack developer accountable for the whole delivery. I also use AI inside the development workflow to move faster, validate ideas, and keep quality high.",
    "hero.ctaPrimary": "Start on WhatsApp",
    "hero.ctaSecondary": "See services",
    "hero.statOne": "years shipping software",
    "hero.statTwo": "MVP to production",
    "hero.statThree": "agents, RAG, automation",
    "trust.copy": "Fast answers. Clear scope. Reliable delivery for UAE teams.",
    "trust.cta": "Book a project call",
    "proofBand.one": "high-demand UAE project categories",
    "proofBand.two": "used for faster delivery and smarter workflows",
    "proofBand.three": "validation before expensive full builds",
    "intro.eyebrow": "Why clients engage",
    "intro.title": "Direct technical ownership, without agency overhead.",
    "intro.copy":
      "Clients come to PalmStack when they need someone who can understand the business problem, design the system, and ship it without layers of handoff. We keep the process simple: quick WhatsApp conversations, clear scope, weekly progress, and software that reduces manual work, improves the customer experience, and gives the team better visibility.",
    "services.eyebrow": "Services",
    "services.title": "What UAE teams can hire me to validate and build.",
    "services.oneTitle": "POC and MVP validation",
    "services.oneCopy":
      "Validate the idea, core workflow, technical risk, and first MVP before committing to a full platform build.",
    "services.oneCta": "Validate an MVP",
    "services.twoTitle": "Backend and cloud systems",
    "services.twoCopy":
      "Django, FastAPI, Node.js, PostgreSQL, AWS, API integrations, background jobs, observability, and CI/CD.",
    "services.twoCta": "Plan the backend",
    "services.threeTitle": "Mobile apps",
    "services.threeCopy":
      "React Native and Expo apps for customers, staff, field teams, notifications, offline flows, and secure sync.",
    "services.threeCta": "Build the app",
    "services.fourTitle": "AI workflow automation",
    "services.fourCopy":
      "Agentic assistants, RAG search, document workflows, tool-calling agents, approvals, audit logs, and AI-assisted delivery.",
    "services.fourCta": "Automate a workflow",
    "work.eyebrow": "Case study directions",
    "work.title": "Four realistic UAE project types clients are actively looking for.",
    "case.challenge": "Challenge",
    "case.solution": "Solution",
    "case.impact": "Expected impact",
    "projects.oneKicker": "MVPs and business platforms",
    "projects.oneTitle": "Booking, payments, and operations portal",
    "projects.oneCopy":
      "A production-ready platform for clinics, salons, maintenance firms, training centers, or home-service companies that need online bookings, staff scheduling, customer accounts, payments, VAT-aware invoices, dashboards, and admin approvals.",
    "projects.oneChallenge": "Manual bookings, scattered customer data, and no real-time view of staff capacity.",
    "projects.oneSolution": "A booking portal, admin dashboard, payment flow, and role-based operations backend.",
    "projects.oneImpact": "Fewer missed leads, faster scheduling, cleaner reporting, and better customer follow-up.",
    "projects.oneCta": "Discuss a similar build",
    "projects.twoKicker": "Backend and cloud systems",
    "projects.twoTitle": "WhatsApp lead-to-CRM automation backend",
    "projects.twoCopy":
      "A backend that captures WhatsApp, website, and ad leads, creates CRM records, assigns owners, triggers follow-ups, syncs files, and gives managers a clear pipeline dashboard.",
    "projects.twoChallenge": "Leads arrive from too many channels and disappear before sales teams follow up.",
    "projects.twoImpact": "Faster response, fewer lost inquiries, and clearer lead ownership.",
    "projects.twoCta": "Plan an integration backend",
    "projects.threeKicker": "Mobile apps",
    "projects.threeTitle": "Customer app for delivery, bookings, or field service",
    "projects.threeCopy":
      "A cross-platform app for UAE customers and field teams with onboarding, service requests, live status, push notifications, secure sync, payments, and Arabic-ready UX foundations.",
    "projects.threeChallenge": "Customers keep asking for updates while field teams work from calls and spreadsheets.",
    "projects.threeImpact": "Clear status updates, fewer support calls, and smoother field operations.",
    "projects.threeCta": "Plan a mobile app",
    "projects.fourKicker": "AI workflow automation",
    "projects.fourTitle": "Invoice, PO, and document approval agent",
    "projects.fourCopy":
      "An agentic workflow for SMEs that extracts data from invoices, POs, contracts, and forms, checks rules, routes approvals, updates ERP/CRM records, and logs every action for review.",
    "projects.fourChallenge": "Finance and operations teams waste hours checking documents and chasing approvals.",
    "projects.fourImpact": "Shorter approval cycles, fewer data-entry errors, and better audit visibility.",
    "projects.fourCta": "See the AI stack",
    "proof.eyebrow": "Proof buyers look for",
    "proof.title": "Trust signals that matter before a UAE client sends the first message.",
    "proof.oneTitle": "Case-study thinking",
    "proof.oneCopy":
      "Every build is framed around the business challenge, the system shipped, and the outcome the client needs to measure.",
    "proof.twoTitle": "Senior technical ownership",
    "proof.twoCopy":
      "The same person who scopes the solution also designs the architecture, builds the core system, and explains tradeoffs clearly.",
    "proof.threeTitle": "AI-assisted delivery",
    "proof.threeCopy":
      "AI is used to speed up research, prototyping, testing, documentation, and developer productivity while keeping human review in control.",
    "industries.title": "Best-fit UAE industries",
    "industries.one": "Clinics and healthcare services",
    "industries.two": "Real estate and property services",
    "industries.three": "Logistics and field operations",
    "industries.four": "Training centers and education",
    "industries.five": "Retail, e-commerce, and marketplaces",
    "industries.six": "Professional services and internal teams",
    "areas.title": "UAE service areas",
    "areas.one": "Dubai software consulting",
    "areas.two": "Abu Dhabi business platforms",
    "areas.three": "Sharjah SME automation",
    "areas.four": "UAE-wide remote delivery",
    "testimonials.eyebrow": "Testimonials",
    "testimonials.title": "The kind of feedback PalmStack is designed to earn.",
    "testimonials.oneQuote":
      "PalmStack helped us turn a loose idea into a clear MVP plan. The scope was practical, the risks were explained, and we knew what to build first.",
    "testimonials.oneName": "Founder",
    "testimonials.oneRole": "UAE service business",
    "testimonials.twoQuote":
      "The biggest value was direct access to the person making the technical decisions. No delays, no confusing handoff, just clear weekly progress.",
    "testimonials.twoName": "Operations lead",
    "testimonials.twoRole": "Field-service company",
    "testimonials.threeQuote":
      "We wanted AI automation, but not a black box. PalmStack framed it around approvals, audit logs, and measurable time savings.",
    "testimonials.threeName": "Finance manager",
    "testimonials.threeRole": "SME operations team",
    "ai.eyebrow": "AI agentic systems",
    "ai.title": "Production AI, built around control and measurable value.",
    "ai.leadTitle": "Not a chatbot. A controlled business workflow.",
    "ai.leadCopy":
      "I design agents that retrieve company knowledge, call approved tools, wait for human sign-off, log actions, and recover safely when APIs or models fail.",
    "ai.toolOneLabel": "Orchestration",
    "ai.toolOneCopy": "Multi-step agents, handoffs, tools, guardrails, tracing, and controlled execution.",
    "ai.toolTwoLabel": "Python agent layer",
    "ai.toolTwoCopy": "Typed Python agents with validation patterns that fit naturally beside FastAPI.",
    "ai.toolThreeLabel": "Durable execution",
    "ai.toolThreeCopy": "Long-running jobs, retries, human approval waits, and crash recovery for serious workflows.",
    "ai.toolFourLabel": "AI data",
    "ai.toolFourCopy": "Product data, auth, audit trails, and vector search in one operational database.",
    "ai.toolFiveLabel": "Search scale",
    "ai.toolFiveCopy": "Dedicated retrieval when metadata filtering, hybrid search, and vector scale need their own engine.",
    "ai.toolSixLabel": "Delivery",
    "ai.toolSixCopy": "APIs, deployment, dashboards, integrations, and mobile experiences around the agent.",
    "engagements.eyebrow": "Engagements",
    "engagements.title": "Simple ways to start without a long agency process.",
    "engagements.oneTitle": "POC and MVP validation sprint",
    "engagements.oneCopy":
      "Clarify the business case, prototype the riskiest workflow, validate the MVP scope, and define a build plan before committing to full development.",
    "engagements.oneBest": "Best for: businesses testing a new product or internal tool",
    "engagements.twoTitle": "MVP build",
    "engagements.twoCopy": "Design and ship the first production-ready version of a platform, mobile app, or AI workflow.",
    "engagements.twoBest": "Best for: founders and SMEs ready to launch",
    "engagements.threeTitle": "Technical rescue",
    "engagements.threeCopy":
      "Stabilize an existing app, improve backend reliability, fix deployment issues, or clean up integrations.",
    "engagements.threeBest": "Best for: teams with a live system under pressure",
    "process.eyebrow": "Process",
    "process.title": "A clear path from WhatsApp message to shipped software.",
    "process.oneTitle": "Fast qualification",
    "process.oneCopy":
      "We confirm the goal, users, budget range, timeline, and whether a POC, MVP, automation, or full custom build is the right move.",
    "process.twoTitle": "System map",
    "process.twoCopy": "I define workflows, data, integrations, AI boundaries, risks, and the first releasable version.",
    "process.threeTitle": "Build and launch",
    "process.threeCopy": "We ship in slices, review weekly, track decisions, and move toward production with confidence.",
    "faq.eyebrow": "Questions",
    "faq.title": "Answers before the first call.",
    "faq.oneQuestion": "Do you work with UAE clients remotely?",
    "faq.oneAnswer":
      "Yes. We work remotely with clients across the UAE using WhatsApp, video calls, weekly progress updates, and clear delivery milestones. You get a simple process: define the goal, agree the scope, review progress regularly, and launch in controlled steps.",
    "faq.twoQuestion": "Can you build both the app and backend?",
    "faq.twoAnswer":
      "Yes. I can own backend APIs, PostgreSQL, AWS deployment, React Native apps, admin dashboards, and integrations.",
    "faq.threeQuestion": "What AI work makes sense for SMEs?",
    "faq.threeAnswer":
      "Useful starting points include internal knowledge search, document workflows, support triage, lead qualification, and approval automation.",
    "contact.eyebrow": "Available for UAE freelance projects",
    "contact.title": "Send the goal. I will help turn it into a technical plan.",
    "contact.copy":
      "Best first message: what you want to build, who will use it, your ideal launch window, and whether you already have designs, data, or an existing system.",
    "contact.whatsapp": "Message on WhatsApp",
    "footer.prefix": "(c)",
    "footer.copy": "PalmStack Studio. Full-stack and AI systems for UAE teams.",
    "footer.top": "Back to top",
  },
  ar: {
    metaTitle: "PalmStack Studio | مطور Full-Stack وأنظمة AI في الإمارات",
    metaDescription:
      "استوديو تقني مستقل في الإمارات لبناء منصات الأعمال، تطبيقات الجوال، أنظمة السحابة، وأتمتة AI agentic.",
    "nav.services": "الخدمات",
    "nav.work": "الأعمال",
    "nav.ai": "أنظمة AI",
    "nav.proof": "الدليل",
    "nav.engagements": "طرق التعاون",
    "nav.contact": "تواصل",
    "hero.eyebrow": "PalmStack Studio - شريك تقني مستقل في الإمارات",
    "hero.title": "أطلق التطبيق، أتمت سير العمل، وحافظ على موثوقية النظام.",
    "hero.lede":
      "أساعد المؤسسين والشركات الصغيرة والمتوسطة في الإمارات على بناء منصات ويب، تطبيقات جوال، Backends سحابية، وأنظمة AI agents جاهزة للإنتاج مع مطور Full-Stack أول مسؤول عن التسليم بالكامل. أستخدم AI أيضا داخل سير التطوير لتسريع العمل، اختبار الأفكار، والحفاظ على جودة عالية.",
    "hero.ctaPrimary": "ابدأ عبر WhatsApp",
    "hero.ctaSecondary": "شاهد الخدمات",
    "hero.statOne": "سنوات في تسليم البرمجيات",
    "hero.statTwo": "من MVP إلى الإنتاج",
    "hero.statThree": "Agents و RAG وأتمتة",
    "trust.copy": "إجابات سريعة. نطاق واضح. تسليم موثوق لفرق الإمارات.",
    "trust.cta": "احجز مكالمة مشروع",
    "proofBand.one": "فئات مشاريع مطلوبة في الإمارات",
    "proofBand.two": "للتسليم الأسرع وسير العمل الأذكى",
    "proofBand.three": "تحقق قبل بناء كامل مكلف",
    "intro.eyebrow": "لماذا يتواصل العملاء",
    "intro.title": "ملكية تقنية مباشرة بدون تعقيد الوكالات.",
    "intro.copy":
      "يتواصل العملاء مع PalmStack عندما يحتاجون إلى شخص يفهم مشكلة العمل، يصمم النظام، ويسلمه بدون طبقات كثيرة من التنسيق. نجعل العملية بسيطة: محادثات WhatsApp سريعة، نطاق واضح، تقدم أسبوعي، وبرمجيات تقلل العمل اليدوي، تحسن تجربة العميل، وتمنح الفريق رؤية أفضل.",
    "services.eyebrow": "الخدمات",
    "services.title": "ما الذي يمكن لفرق الإمارات توظيفي لاختباره وبنائه.",
    "services.oneTitle": "اختبار POC و MVP",
    "services.oneCopy": "اختبار الفكرة، سير العمل الأساسي، المخاطر التقنية، وأول MVP قبل الالتزام ببناء منصة كاملة.",
    "services.oneCta": "اختبر MVP",
    "services.twoTitle": "Backend وأنظمة السحابة",
    "services.twoCopy":
      "Django و FastAPI و Node.js و PostgreSQL و AWS وتكاملات API والمهام الخلفية والمراقبة و CI/CD.",
    "services.twoCta": "خطط للـ backend",
    "services.threeTitle": "تطبيقات الجوال",
    "services.threeCopy":
      "تطبيقات React Native و Expo للعملاء والموظفين وفرق الميدان والتنبيهات والعمل بدون إنترنت والمزامنة الآمنة.",
    "services.threeCta": "ابن التطبيق",
    "services.fourTitle": "أتمتة سير العمل بالـ AI",
    "services.fourCopy": "مساعدون agentic، بحث RAG، سير عمل المستندات، tool-calling agents، موافقات، سجلات تدقيق، وتسليم مدعوم بالـ AI.",
    "services.fourCta": "أتمت سير عمل",
    "work.eyebrow": "اتجاهات دراسات حالة",
    "work.title": "أربعة أنواع مشاريع واقعية يبحث عنها عملاء الإمارات فعليا.",
    "case.challenge": "التحدي",
    "case.solution": "الحل",
    "case.impact": "الأثر المتوقع",
    "projects.oneKicker": "MVPs ومنصات الأعمال",
    "projects.oneTitle": "بوابة للحجوزات والمدفوعات والعمليات",
    "projects.oneCopy":
      "منصة جاهزة للإنتاج للعيادات، الصالونات، شركات الصيانة، مراكز التدريب، أو خدمات المنازل التي تحتاج حجوزات إلكترونية، جدولة موظفين، حسابات عملاء، مدفوعات، فواتير VAT-aware، لوحات بيانات، وموافقات إدارية.",
    "projects.oneChallenge": "حجوزات يدوية، بيانات عملاء متفرقة، وعدم وجود رؤية مباشرة لطاقة الموظفين.",
    "projects.oneSolution": "بوابة حجز، لوحة إدارة، مسار دفع، و backend للعمليات حسب الصلاحيات.",
    "projects.oneImpact": "تقليل العملاء الضائعين، جدولة أسرع، تقارير أنظف، ومتابعة أفضل للعملاء.",
    "projects.oneCta": "ناقش مشروعا مشابها",
    "projects.twoKicker": "Backend وأنظمة السحابة",
    "projects.twoTitle": "Backend لتحويل عملاء WhatsApp إلى CRM",
    "projects.twoCopy":
      "Backend يلتقط العملاء المحتملين من WhatsApp والموقع والإعلانات، ينشئ سجلات CRM، يوزع المسؤوليات، يشغل المتابعات، يزامن الملفات، ويمنح المديرين لوحة واضحة لمسار المبيعات.",
    "projects.twoChallenge": "العملاء المحتملون يصلون من قنوات كثيرة ويضيعون قبل أن يتابعهم فريق المبيعات.",
    "projects.twoImpact": "استجابة أسرع، استفسارات ضائعة أقل، وملكية أوضح لكل lead.",
    "projects.twoCta": "خطط لتكامل backend",
    "projects.threeKicker": "تطبيقات الجوال",
    "projects.threeTitle": "تطبيق عملاء للتوصيل أو الحجوزات أو الخدمات الميدانية",
    "projects.threeCopy":
      "تطبيق cross-platform لعملاء الإمارات وفرق الميدان مع onboarding، طلبات خدمة، حالة مباشرة، push notifications، مزامنة آمنة، مدفوعات، وأساس UX جاهز للعربية.",
    "projects.threeChallenge": "العملاء يطلبون تحديثات باستمرار بينما تعمل فرق الميدان عبر المكالمات والجداول.",
    "projects.threeImpact": "تحديثات حالة أوضح، مكالمات دعم أقل، وعمليات ميدانية أكثر سلاسة.",
    "projects.threeCta": "خطط لتطبيق جوال",
    "projects.fourKicker": "أتمتة سير العمل بالـ AI",
    "projects.fourTitle": "Agent للموافقة على الفواتير و PO والمستندات",
    "projects.fourCopy":
      "سير عمل agentic للشركات الصغيرة والمتوسطة يستخرج البيانات من الفواتير و POs والعقود والنماذج، يتحقق من القواعد، يوجه الموافقات، يحدث ERP/CRM، ويسجل كل إجراء للمراجعة.",
    "projects.fourChallenge": "فرق المالية والعمليات تهدر ساعات في مراجعة المستندات ومتابعة الموافقات.",
    "projects.fourImpact": "دورات موافقة أقصر، أخطاء إدخال أقل، ورؤية أفضل للتدقيق.",
    "projects.fourCta": "شاهد Stack الـ AI",
    "proof.eyebrow": "الدليل الذي يبحث عنه المشترون",
    "proof.title": "إشارات ثقة مهمة قبل أن يرسل عميل في الإمارات أول رسالة.",
    "proof.oneTitle": "تفكير مبني على دراسات حالة",
    "proof.oneCopy": "كل بناء يتم ربطه بتحدي العمل، النظام الذي يتم تسليمه، والنتيجة التي يحتاج العميل إلى قياسها.",
    "proof.twoTitle": "ملكية تقنية أولى",
    "proof.twoCopy": "نفس الشخص الذي يحدد الحل يصمم المعمارية، يبني النظام الأساسي، ويشرح المفاضلات بوضوح.",
    "proof.threeTitle": "تسليم مدعوم بالـ AI",
    "proof.threeCopy": "يستخدم AI لتسريع البحث والنمذجة والاختبار والتوثيق وإنتاجية التطوير مع بقاء المراجعة البشرية مسيطرة.",
    "industries.title": "القطاعات الأنسب في الإمارات",
    "industries.one": "العيادات والخدمات الصحية",
    "industries.two": "العقارات وخدمات الملكية",
    "industries.three": "اللوجستيات والعمليات الميدانية",
    "industries.four": "مراكز التدريب والتعليم",
    "industries.five": "التجزئة والتجارة الإلكترونية والأسواق",
    "industries.six": "الخدمات المهنية والفرق الداخلية",
    "areas.title": "مناطق الخدمة في الإمارات",
    "areas.one": "استشارات برمجية في دبي",
    "areas.two": "منصات أعمال في أبوظبي",
    "areas.three": "أتمتة للشركات الصغيرة والمتوسطة في الشارقة",
    "areas.four": "تسليم عن بعد في جميع الإمارات",
    "testimonials.eyebrow": "آراء العملاء",
    "testimonials.title": "نوع الانطباع الذي صمم PalmStack لكسبه.",
    "testimonials.oneQuote":
      "ساعدنا PalmStack في تحويل فكرة غير واضحة إلى خطة MVP واضحة. كان النطاق عمليا، وتم شرح المخاطر، وعرفنا ما الذي يجب بناؤه أولا.",
    "testimonials.oneName": "مؤسس",
    "testimonials.oneRole": "شركة خدمات في الإمارات",
    "testimonials.twoQuote":
      "أكبر قيمة كانت الوصول المباشر للشخص الذي يتخذ القرارات التقنية. لا تأخير، لا تسليم مربك، فقط تقدم أسبوعي واضح.",
    "testimonials.twoName": "قائد عمليات",
    "testimonials.twoRole": "شركة خدمات ميدانية",
    "testimonials.threeQuote":
      "كنا نريد أتمتة AI، لكن ليس صندوقا أسود. ربط PalmStack الحل بالموافقات وسجلات التدقيق وتوفير الوقت القابل للقياس.",
    "testimonials.threeName": "مدير مالي",
    "testimonials.threeRole": "فريق عمليات SME",
    "ai.eyebrow": "أنظمة AI agentic",
    "ai.title": "AI للإنتاج مبني حول التحكم والقيمة القابلة للقياس.",
    "ai.leadTitle": "ليس chatbot. بل سير عمل تجاري مضبوط.",
    "ai.leadCopy":
      "أصمم agents تسترجع معرفة الشركة، تستدعي أدوات معتمدة، تنتظر موافقة بشرية، تسجل الإجراءات، وتتعافى بأمان عند فشل APIs أو النماذج.",
    "ai.toolOneLabel": "Orchestration",
    "ai.toolOneCopy": "Agents متعددة الخطوات، handoffs، tools، guardrails، tracing، وتنفيذ مضبوط.",
    "ai.toolTwoLabel": "طبقة Python agent",
    "ai.toolTwoCopy": "Agents مكتوبة بـ Python مع validation patterns تعمل بسلاسة بجانب FastAPI.",
    "ai.toolThreeLabel": "تنفيذ طويل الأمد",
    "ai.toolThreeCopy": "مهام طويلة، retries، انتظار موافقات بشرية، واستعادة بعد الأعطال لسير العمل الجاد.",
    "ai.toolFourLabel": "بيانات AI",
    "ai.toolFourCopy": "بيانات المنتج، الصلاحيات، سجلات التدقيق، و vector search داخل قاعدة تشغيلية واحدة.",
    "ai.toolFiveLabel": "بحث على نطاق واسع",
    "ai.toolFiveCopy": "Retrieval مخصص عندما تحتاج metadata filtering و hybrid search و vector scale إلى محرك مستقل.",
    "ai.toolSixLabel": "التسليم",
    "ai.toolSixCopy": "APIs، نشر، dashboards، تكاملات، وتجارب جوال حول الـ agent.",
    "engagements.eyebrow": "طرق التعاون",
    "engagements.title": "طرق بسيطة للبدء بدون عملية وكالة طويلة.",
    "engagements.oneTitle": "Sprint لاختبار POC و MVP",
    "engagements.oneCopy": "توضيح الجدوى التجارية، بناء نموذج لأعلى سير عمل مخاطرة، اختبار نطاق MVP، وتحديد خطة البناء قبل الالتزام بالتطوير الكامل.",
    "engagements.oneBest": "الأفضل لـ: الشركات التي تختبر منتجا جديدا أو أداة داخلية",
    "engagements.twoTitle": "بناء MVP",
    "engagements.twoCopy": "تصميم وتسليم أول نسخة جاهزة للإنتاج من منصة أو تطبيق جوال أو سير عمل AI.",
    "engagements.twoBest": "الأفضل لـ: المؤسسين والشركات الجاهزة للإطلاق",
    "engagements.threeTitle": "إنقاذ تقني",
    "engagements.threeCopy": "تثبيت تطبيق قائم، تحسين موثوقية backend، إصلاح النشر، أو ترتيب التكاملات.",
    "engagements.threeBest": "الأفضل لـ: الفرق التي لديها نظام حي تحت ضغط",
    "process.eyebrow": "العملية",
    "process.title": "مسار واضح من رسالة WhatsApp إلى برنامج منشور.",
    "process.oneTitle": "تأهيل سريع",
    "process.oneCopy": "نؤكد الهدف والمستخدمين ونطاق الميزانية والجدول الزمني وما إذا كان POC أو MVP أو الأتمتة أو بناء مخصص كامل هو الخيار الصحيح.",
    "process.twoTitle": "خريطة النظام",
    "process.twoCopy": "أحدد سير العمل والبيانات والتكاملات وحدود AI والمخاطر وأول نسخة قابلة للإطلاق.",
    "process.threeTitle": "بناء وإطلاق",
    "process.threeCopy": "نطلق على مراحل، نراجع أسبوعيا، نوثق القرارات، ونتجه نحو الإنتاج بثقة.",
    "faq.eyebrow": "أسئلة",
    "faq.title": "إجابات قبل المكالمة الأولى.",
    "faq.oneQuestion": "هل تعمل مع عملاء الإمارات عن بعد؟",
    "faq.oneAnswer": "نعم. نعمل عن بعد مع العملاء في جميع أنحاء الإمارات باستخدام WhatsApp ومكالمات الفيديو وتحديثات أسبوعية ومراحل تسليم واضحة. تحصل على عملية بسيطة: تحديد الهدف، الاتفاق على النطاق، مراجعة التقدم بانتظام، ثم الإطلاق بخطوات مضبوطة.",
    "faq.twoQuestion": "هل يمكنك بناء التطبيق والـ backend معا؟",
    "faq.twoAnswer":
      "نعم. يمكنني امتلاك backend APIs و PostgreSQL ونشر AWS وتطبيقات React Native ولوحات الإدارة والتكاملات.",
    "faq.threeQuestion": "ما نوع أعمال AI المناسب للشركات الصغيرة والمتوسطة؟",
    "faq.threeAnswer":
      "بدايات مفيدة تشمل البحث في المعرفة الداخلية، سير عمل المستندات، فرز الدعم، تأهيل العملاء المحتملين، وأتمتة الموافقات.",
    "contact.eyebrow": "متاح لمشاريع حرة في الإمارات",
    "contact.title": "أرسل الهدف. سأساعدك في تحويله إلى خطة تقنية.",
    "contact.copy":
      "أفضل رسالة أولى: ماذا تريد أن تبني، من سيستخدمه، موعد الإطلاق المثالي، وهل لديك تصاميم أو بيانات أو نظام قائم.",
    "contact.whatsapp": "راسلني على WhatsApp",
    "footer.prefix": "(c)",
    "footer.copy": "PalmStack Studio. أنظمة Full-Stack و AI لفرق الإمارات.",
    "footer.top": "العودة للأعلى",
  },
};

function applyLanguage(language) {
  const copy = translations[language] || translations.en;
  const isArabic = language === "ar";

  document.documentElement.lang = isArabic ? "ar" : "en";
  document.documentElement.dir = isArabic ? "rtl" : "ltr";
  document.title = copy.metaTitle;

  if (metaDescription) {
    metaDescription.setAttribute("content", copy.metaDescription);
  }

  document.querySelectorAll("[data-i18n]").forEach((element) => {
    const key = element.getAttribute("data-i18n");

    if (copy[key]) {
      element.textContent = copy[key];
    }
  });

  if (languageToggle && currentLangLabel && nextLangLabel) {
    languageToggle.setAttribute("aria-pressed", String(isArabic));
    languageToggle.setAttribute("aria-label", isArabic ? "Switch to English" : "Switch to Arabic");
    currentLangLabel.textContent = isArabic ? "AR" : "EN";
    nextLangLabel.textContent = isArabic ? "EN" : "AR";
  }

  try {
    localStorage.setItem("palmstack-language", language);
  } catch {
    // Some file:// contexts restrict storage; the toggle still works for the current page view.
  }
}

let savedLanguage = "en";

try {
  savedLanguage = localStorage.getItem("palmstack-language") || "en";
} catch {
  savedLanguage = "en";
}

applyLanguage(savedLanguage);

if (languageToggle) {
  languageToggle.addEventListener("click", () => {
    const nextLanguage = document.documentElement.lang === "ar" ? "en" : "ar";
    applyLanguage(nextLanguage);
  });
}

if (contactForm) {
  contactForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const formData = new FormData(contactForm);
    const fields = [
      ["Name", formData.get("name")],
      ["Email", formData.get("email")],
      ["Company", formData.get("company")],
      ["Phone/WhatsApp", formData.get("phone")],
      ["Project type", formData.get("projectType")],
      ["Stage", formData.get("stage")],
      ["Timeline", formData.get("timeline")],
      ["Budget", formData.get("budget")],
      ["Project goal", formData.get("message")],
    ];
    const body = fields
      .map(([label, value]) => `${label}: ${value || "Not provided"}`)
      .join("\n");
    const subject = encodeURIComponent("PalmStack Studio project enquiry");
    const mailBody = encodeURIComponent(body);

    window.location.href = `mailto:hello@palmstack.studio?subject=${subject}&body=${mailBody}`;
  });
}

const contactTranslations = {
  en: {
    navServices: "Services",
    navWork: "Work",
    navProof: "Proof",
    navContact: "Contact",
    heroEyebrow: "Start a project",
    heroTitle: "Tell us what you want to validate, automate, or build.",
    heroCopy:
      "A good first message should make the next step obvious. Use the form for a structured project brief, or start on WhatsApp if you want a faster conversation.",
    nextTitle: "What happens next",
    nextOne: "Quick review of your goal and constraints.",
    nextTwo: "Clear recommendation: POC, MVP, automation, or full build.",
    nextThree: "Next-step scope with timeline and technical risks.",
    formEyebrow: "Project brief",
    formTitle: "A short form for serious enquiries.",
    formCopy:
      "High-converting consulting forms ask enough to qualify the project, but not so much that they slow down the conversation. These fields help us respond with useful technical direction.",
    whatsapp: "Message on WhatsApp",
    name: "Name",
    email: "Work email",
    company: "Company",
    phone: "Phone or WhatsApp",
    need: "What do you need?",
    stage: "Project stage",
    timeline: "Ideal timeline",
    budget: "Budget range",
    goal: "Project goal",
    submit: "Prepare email brief",
    note: "This static form opens your email app with a prepared brief. For fastest response, use WhatsApp.",
  },
  ar: {
    navServices: "الخدمات",
    navWork: "الأعمال",
    navProof: "الدليل",
    navContact: "تواصل",
    heroEyebrow: "ابدأ مشروعا",
    heroTitle: "أخبرنا بما تريد اختباره أو أتمتته أو بناؤه.",
    heroCopy:
      "الرسالة الأولى الجيدة تجعل الخطوة التالية واضحة. استخدم النموذج لملخص مشروع منظم، أو ابدأ عبر WhatsApp إذا أردت محادثة أسرع.",
    nextTitle: "ماذا يحدث بعد ذلك",
    nextOne: "مراجعة سريعة للهدف والقيود.",
    nextTwo: "توصية واضحة: POC أو MVP أو أتمتة أو بناء كامل.",
    nextThree: "نطاق للخطوة التالية مع الجدول الزمني والمخاطر التقنية.",
    formEyebrow: "ملخص المشروع",
    formTitle: "نموذج قصير للاستفسارات الجادة.",
    formCopy:
      "النماذج الجيدة في الاستشارات تطلب ما يكفي لتأهيل المشروع، بدون أن تبطئ المحادثة. هذه الحقول تساعدنا على الرد بتوجيه تقني مفيد.",
    whatsapp: "راسلنا على WhatsApp",
    name: "الاسم",
    email: "البريد المهني",
    company: "الشركة",
    phone: "الهاتف أو WhatsApp",
    need: "ماذا تحتاج؟",
    stage: "مرحلة المشروع",
    timeline: "الجدول الزمني المثالي",
    budget: "نطاق الميزانية",
    goal: "هدف المشروع",
    submit: "جهز ملخص البريد",
    note: "هذا النموذج الثابت يفتح تطبيق البريد برسالة جاهزة. لأسرع رد، استخدم WhatsApp.",
  },
};

function applyContactLanguage(language) {
  if (!contactLanguageToggle) {
    return;
  }

  const copy = contactTranslations[language] || contactTranslations.en;
  const isArabic = language === "ar";

  document.documentElement.lang = isArabic ? "ar" : "en";
  document.documentElement.dir = isArabic ? "rtl" : "ltr";

  document.querySelectorAll("[data-contact-i18n]").forEach((element) => {
    const key = element.getAttribute("data-contact-i18n");

    if (copy[key]) {
      element.textContent = copy[key];
    }
  });

  const current = document.querySelector("[data-contact-lang-current]");
  const next = document.querySelector("[data-contact-lang-next]");

  contactLanguageToggle.setAttribute("aria-pressed", String(isArabic));
  contactLanguageToggle.setAttribute("aria-label", isArabic ? "Switch to English" : "Switch to Arabic");

  if (current && next) {
    current.textContent = isArabic ? "AR" : "EN";
    next.textContent = isArabic ? "EN" : "AR";
  }
}

if (contactLanguageToggle) {
  applyContactLanguage("en");
  contactLanguageToggle.addEventListener("click", () => {
    const nextLanguage = document.documentElement.lang === "ar" ? "en" : "ar";
    applyContactLanguage(nextLanguage);
  });
}
