# SEO TODO

## Implemented in this pass

- [x] Add canonical URLs to all pages.
- [x] Add Open Graph and Twitter card metadata.
- [x] Add structured data for Organization, ProfessionalService, WebSite, FAQPage, ContactPage, and Service pages.
- [x] Add `robots.txt`.
- [x] Add `sitemap.xml`.
- [x] Create dedicated service pages for higher-intent search queries.
- [x] Add UAE service-area signals for Dubai, Abu Dhabi, Sharjah, and UAE-wide remote delivery.
- [x] Add bilingual support to the contact page.
- [x] Run final checks for titles, descriptions, headings, schema, internal links, and crawl files.

## Later, once real data is available

- [ ] Deploy the site on the real domain.
- [ ] Submit `sitemap.xml` in Google Search Console after deployment.
- [ ] Replace representative testimonials with real client testimonials.
- [ ] Replace conceptual case studies with real case studies and measurable outcomes.
- [ ] Add real phone number, WhatsApp number, LinkedIn profile, and business address or service-area details.
- [ ] Add Google Business Profile link if PalmStack Studio registers locally.
- [ ] Register PalmStack Studio on relevant UAE business/freelance directories.
- [ ] Replace placeholder domain if not using `https://palmstack.studio/`.
